﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace The_Horse_Race
{
    
    public class Horses
    {
        private string horseName;
        private PictureBox picturebox;
        private const int speed;
        private Random random;

        public class horses(string horseName, PictureBox picturebox, Random random)
            {
                
            }
       
    }
}
